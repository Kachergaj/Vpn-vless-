APP_OPTIM := release
APP_PLATFORM := android-26
APP_ABI := armeabi-v7a arm64-v8a
APP_CFLAGS := -O3 -fvisibility=hidden
APP_STL := c++_shared
APP_SUPPORT_FLEXIBLE_PAGE_SIZES := true
NDK_TOOLCHAIN_VERSION := clang
