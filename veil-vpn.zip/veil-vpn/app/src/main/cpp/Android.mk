# Нативная сборка: JNI-мост tun2socks + исходники hev-socks5-tunnel.
#
# Собирается через ndk-build (gradle externalNativeBuild.ndkBuild).
# Исходники hev-socks5-tunnel лежат в third_party/hev-socks5-tunnel
# (клонируются с сабмодулями — см. README.md).

TOP_PATH := $(call my-dir)
HEV_PATH := $(TOP_PATH)/third_party/hev-socks5-tunnel

# Статические библиотеки: yaml, lwip, hev-task-system
include $(HEV_PATH)/third-part/yaml/Android.mk
include $(HEV_PATH)/third-part/lwip/Android.mk
include $(HEV_PATH)/third-part/hev-task-system/Android.mk

# Исходники hev-socks5-tunnel (рекурсивно, включая src/core)
HEV_SRC := $(shell cd $(HEV_PATH)/src && find . -name '*.c' | sed 's|^\./||')

include $(CLEAR_VARS)
# Сторонние Android.mk меняют LOCAL_PATH — возвращаем свой корень.
LOCAL_PATH := $(TOP_PATH)
LOCAL_MODULE := veilnative
LOCAL_SRC_FILES := tun2socks.cpp \
                   $(addprefix third_party/hev-socks5-tunnel/src/,$(HEV_SRC))
LOCAL_C_INCLUDES := \
    $(HEV_PATH)/src \
    $(HEV_PATH)/src/misc \
    $(HEV_PATH)/src/core/include \
    $(HEV_PATH)/third-part/yaml/include \
    $(HEV_PATH)/third-part/lwip/src/include \
    $(HEV_PATH)/third-part/lwip/src/ports/include \
    $(HEV_PATH)/third-part/hev-task-system/include
LOCAL_CFLAGS += -DFD_SET_DEFINED -DSOCKLEN_T_DEFINED -DENABLE_LIBRARY
LOCAL_CFLAGS += -fno-stack-clash-protection -O3
LOCAL_STATIC_LIBRARIES := libyaml liblwip libhev-task-system
LOCAL_LDLIBS := -llog
LOCAL_LDFLAGS += -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384
include $(BUILD_SHARED_LIBRARY)
