# Правила R8/ProGuard для Veil VPN.
#
# 1) JNI: имена классов и native-методов должны сохраниться, иначе
#    UnsatisfiedLinkError при вызове из native-кода.
#    (По умолчанию правило -keepclasseswithmembernames есть в
#    proguard-android-optimize.txt, но дублируем явно.)
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

-keep class com.veil.vpn.core.NativeCore { *; }
-keep class com.veil.vpn.core.Tun2Socks { *; }

# 2) Модель профилей: используется при сериализации в JSON вручную,
#    но имена полей читаются рефлексией в тестах и при миграциях.
-keep class com.veil.vpn.model.** { *; }

# 3) Go-обёртка Xray-core (c-shared) и её точки входа.
-keep class veilvpn.xraycore.** { *; }
-keep class core.** { *; }
