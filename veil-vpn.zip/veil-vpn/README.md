# Veil VPN

Android-клиент VPN-доступа с антицензурным транспортом **VLESS + Reality**
(ядро Xray-core), реализованный поверх системного `VpnService` с TUN-интерфейсом.

> **Назначение.** Защита личного трафика и доступ к ресурсам, ограниченным в сети
> пользователя. Приложение **не** предназначено для обхода корпоративных политик
> безопасности и **не** содержит функций воздействия на средства защиты информации.
> Пользователь несёт ответственность за соблюдение применимого законодательства.
> Подробнее — `docs/ARCHITECTURE.md`, раздел 0 и `docs/TESTING.md`.

---

## Что внутри

| Компонент | Реализация |
|---|---|
| TUN-интерфейс | `VpnService.Builder` — IPv4 + IPv6, маршрут по умолчанию, FakeDNS |
| Движок | Xray-core v1.260327.0, собранный как `c-shared` (`libxraycore.so`) |
| Защита сокетов | штатный `internet.RegisterDialerController` → `VpnService.protect(fd)` |
| TUN → SOCKS5 | `hev-socks5-tunnel` (вендорён в `app/src/main/cpp/third_party/`) |
| Протоколы | VLESS + Reality (основной), VLESS + XHTTP + Reality, импорт VMess/Trojan/SS/Hysteria2 |
| DNS | FakeDNS (`198.18.0.0/16`) + DoH, без утечек к оператору |
| Устойчивость | Kill switch (TUN не снимается при сбое ядра), авторестарт при смене сети |
| Хранение | Профили — AES-256-GCM, ключ в Android Keystore; логов трафика нет |

## Структура

```
veil-vpn/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── cpp/                     # нативная часть: ndk-build (Android.mk)
│       │   ├── tun2socks.cpp        # JNI → hev_socks5_tunnel
│       │   └── third_party/hev-socks5-tunnel/
│       └── java/com/veil/vpn/
│           ├── App.kt, di/          # Application, ServiceLocator
│           ├── model/               # Profile, TunnelState, LinkParser
│           ├── data/                # SecureStore (Keystore), ProfileRepository
│           ├── core/                # CoreEngine, XrayConfigBuilder, NativeCore, Tun2Socks, LogSink
│           ├── service/             # VeilVpnService, TunnelManager, KillSwitch, NetworkMonitor, SplitTunnelPolicy
│           ├── net/                 # SubscriptionManager, SubscriptionWorker
│           └── ui/                  # Compose: connect, profiles, logs, disclaimer
├── native/go/xraycore/              # Go-обёртка Xray-core + JNI-мост (protect)
├── .github/workflows/android.yml    # облачная сборка (GitHub Actions)
├── docs/
│   ├── ARCHITECTURE.md              # архитектура, протоколы, DPI, DNS, kill switch
│   └── TESTING.md                   # чек-лист тестирования
└── gradle/libs.versions.toml
```

## Сборка

### 1. Тулчейн

| Компонент | Версия |
|---|---|
| JDK | 17 |
| Android SDK | platform 35, build-tools 35.0.0 |
| NDK | 26.1.10909125 |
| Gradle | 8.9 (AGP 8.7.3, Kotlin 2.0.21) |
| Go | 1.27+ (требование Xray-core v1.260327.0) |

```bash
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0" "ndk;26.1.10909125"
```

### 2. Ядро Xray-core (libxraycore.so)

Форк Xray-core **не нужен** — защита сокетов подключается штатным API
`internet.RegisterDialerController`.

```bash
cd native/go/xraycore
export ANDROID_NDK_HOME=$ANDROID_SDK_ROOT/ndk/26.1.10909125
export PATH=$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin:$PATH

CGO_ENABLED=1 GOOS=android GOARCH=arm64 \
  CC=aarch64-linux-android26-clang CXX=aarch64-linux-android26-clang++ \
  go build -buildmode=c-shared -ldflags="-s -w" \
  -o ../../../app/src/main/jniLibs/arm64-v8a/libxraycore.so .

CGO_ENABLED=1 GOOS=android GOARCH=arm GOARM=7 \
  CC=armv7a-linux-androideabi26-clang CXX=armv7a-linux-androideabi26-clang++ \
  go build -buildmode=c-shared -ldflags="-s -w" \
  -o ../../../app/src/main/jniLibs/armeabi-v7a/libxraycore.so .
```

Исходники `hev-socks5-tunnel` уже вендорёны в `app/src/main/cpp/third_party/`
(вместе с сабмодулями lwip/yaml/hev-task-system), отдельная загрузка не нужна.

### 3. Приложение

```bash
./gradlew :app:assembleRelease      # APK
./gradlew :app:testDebugUnitTest    # unit-тесты парсера ссылок
```

Подпись: создайте `keystore.properties` в корне (файл в `.gitignore`):

```properties
storeFile=release.jks
storePassword=...
keyAlias=...
keyPassword=...
```

Облачная сборка (GitHub Actions) описана в `.github/workflows/android.yml`:
нужны секреты `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Серверная часть

Размещается **за пределами РФ**. Минимальная конфигурация Xray-core:

```json
{
  "inbounds": [{
    "tag": "vless-reality",
    "port": 443,
    "protocol": "vless",
    "settings": {
      "clients": [{ "id": "<UUID>", "flow": "xtls-rprx-vision" }],
      "decryption": "none"
    },
    "streamSettings": {
      "network": "tcp",
      "security": "reality",
      "realitySettings": {
        "show": false,
        "dest": "www.microsoft.com:443",
        "xver": 0,
        "serverNames": ["www.microsoft.com"],
        "privateKey": "<PRIVATE_KEY>",
        "shortIds": ["<SHORT_ID>"],
        "spiderX": "/"
      }
    }
  }],
  "outbounds": [{ "protocol": "freedom", "tag": "direct" }]
}
```

Клиентская ссылка (то, что импортируется в приложение):

```
vless://<UUID>@<host>:443?type=tcp&security=reality&pbk=<PUBLIC_KEY>&sid=<SHORT_ID>&sni=www.microsoft.com&fp=chrome&flow=xtls-rprx-vision&spx=%2F#MyServer
```

## Использование

1. Открыть приложение → принять правовое уведомление.
2. «Профили» → «Добавить профиль» → «По ссылке» (или «Из подписки», «Ручной ввод»).
3. Выбрать профиль на главном экране → кнопка питания.
4. При первом подключении Android покажет системный запрос VPN-разрешения.

## Известные ограничения

* `force-stop` приложения снимает VPN силами ОС — защита возможна только через
  Always-on VPN + «Блокировка без VPN» (DevicePolicyManager, требует прав
  администратора устройства).
* Приложения, исключённые из туннеля (split tunneling), используют DNS оператора.
* Работоспособность при конкретном типе DPI не гарантируется.

## Документы

* `docs/ARCHITECTURE.md` — архитектура, протоколы, обход DPI, DNS, kill switch,
  разбор «жёстких точек интеграции» (protect() и передача TUN fd).
* `docs/TESTING.md` — чек-лист тестирования (утечки DNS, смена сети, активный
  DPI, kill switch, приватность, критерии приёмки).
